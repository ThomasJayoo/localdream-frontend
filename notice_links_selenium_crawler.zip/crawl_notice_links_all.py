
import json
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from datetime import datetime

def extract_notices_from_page(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    notices = []

    table = soup.find("table")
    if not table:
        return []

    for row in table.find_all("tr"):
        cols = row.find_all("td")
        if len(cols) < 5:
            continue

        title_cell = cols[1]
        date_cell = cols[4]

        a_tag = title_cell.find("a")
        if not a_tag:
            continue

        title = a_tag.get_text(strip=True)
        href = a_tag.get("href")
        full_url = href if href.startswith("http") else base_url.rstrip("/") + "/" + href.lstrip("/")

        raw_date = date_cell.get_text(strip=True)
        try:
            parsed_date = datetime.strptime(raw_date, "%Y-%m-%d").isoformat()
        except:
            parsed_date = datetime.now().isoformat()

        notices.append({
            "text": title,
            "url": full_url,
            "date": parsed_date
        })

    return notices

def crawl_all_notices(excel_path="지자체.xlsx", output_path="notice_links_all.json"):
    df = pd.read_excel(excel_path)
    df["지역명"] = df["시도명"].astype(str).str.strip() + " " + df["지자체"].astype(str).str.strip()

    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    driver = webdriver.Chrome(options=chrome_options)

    result = {}

    for _, row in df.iterrows():
        region = row["지역명"]
        url = row["홈페이지"]
        print(f"크롤링 중: {region} → {url}")
        if not isinstance(url, str) or not url.startswith("http"):
            result[region] = [{"error": "invalid url"}]
            continue

        try:
            driver.get(url)
            time.sleep(2.5)
            notices = extract_notices_from_page(driver.page_source, url)
            if notices:
                result[region] = notices
            else:
                result[region] = [{"error": "no link found"}]
        except Exception as e:
            result[region] = [{"error": str(e)}]

    driver.quit()

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"✅ notice_links_all.json 생성 완료 ({len(result)}개 지자체)")
